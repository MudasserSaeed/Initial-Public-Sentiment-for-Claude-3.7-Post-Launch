import sys
import json
import re
import datetime
from collections import Counter

# Load the Twitter search results
with open('/home/ubuntu/claude_analysis/twitter_data/twitter_search_results_20250302_150110.json', 'r') as f:
    twitter_data = json.load(f)

# Function to extract tweets from the Twitter API response
def extract_tweets(data):
    tweets = []
    
    for query, query_results in data.items():
        for search_type, results in query_results.items():
            if 'result' in results and 'timeline' in results['result'] and 'instructions' in results['result']['timeline']:
                for instruction in results['result']['timeline']['instructions']:
                    if 'entries' in instruction:
                        for entry in instruction['entries']:
                            if 'content' in entry and 'items' in entry['content']:
                                for item in entry['content']['items']:
                                    if 'item' in item and 'itemContent' in item['item']:
                                        tweet_data = {
                                            'query': query,
                                            'search_type': search_type,
                                            'content': None,
                                            'username': None,
                                            'name': None,
                                            'timestamp': None,
                                            'likes': None,
                                            'retweets': None,
                                            'replies': None,
                                            'followers': None,
                                            'verified': None
                                        }
                                        
                                        # Extract tweet content and metadata
                                        # This structure will depend on the actual API response format
                                        # Adjust as needed based on the actual data structure
                                        
                                        # Add to tweets list if we have content
                                        if tweet_data['content']:
                                            tweets.append(tweet_data)
    
    return tweets

# Simple sentiment analysis function
def analyze_sentiment(text):
    if not text:
        return "neutral"
    
    # Lists of positive and negative words/phrases
    positive_words = [
        'amazing', 'awesome', 'excellent', 'fantastic', 'great', 'impressive', 
        'love', 'best', 'better', 'improved', 'improvement', 'innovative', 
        'game-changer', 'revolutionary', 'breakthrough', 'excited', 'exciting',
        'powerful', 'fast', 'faster', 'accurate', 'accurate', 'helpful',
        'recommend', 'recommended', 'worth', 'valuable', 'useful', 'easy',
        'intuitive', 'smart', 'intelligent', 'brilliant', 'incredible',
        'outperforms', 'outperforming', 'beats', 'exceeds', 'exceeded',
        'happy', 'pleased', 'satisfied', 'satisfaction', 'impressive',
        'impressed', 'wow', 'amazing', 'cool', 'nice', 'good', 'great'
    ]
    
    negative_words = [
        'bad', 'terrible', 'awful', 'horrible', 'disappointing', 'disappointed',
        'slow', 'slower', 'buggy', 'bug', 'issue', 'problem', 'error', 'fail',
        'failed', 'failure', 'poor', 'worse', 'worst', 'useless', 'expensive',
        'overpriced', 'not worth', 'difficult', 'hard', 'complicated', 'confusing',
        'confused', 'frustrating', 'frustrated', 'frustration', 'annoying',
        'annoyed', 'hate', 'dislike', 'mediocre', 'meh', 'underwhelming',
        'underperforms', 'underperforming', 'lacks', 'lacking', 'limited',
        'limitation', 'limitations', 'not good', 'not great', 'not working',
        'doesn\'t work', 'doesn\'t help', 'unhelpful', 'waste', 'wasted'
    ]
    
    # Count positive and negative words
    text_lower = text.lower()
    positive_count = sum(1 for word in positive_words if re.search(r'\b' + re.escape(word) + r'\b', text_lower))
    negative_count = sum(1 for word in negative_words if re.search(r'\b' + re.escape(word) + r'\b', text_lower))
    
    # Determine sentiment
    if positive_count > negative_count:
        return "positive"
    elif negative_count > positive_count:
        return "negative"
    else:
        return "neutral"

# Extract tweets
tweets = extract_tweets(twitter_data)

# Analyze sentiment for each tweet
for tweet in tweets:
    if tweet['content']:
        tweet['sentiment'] = analyze_sentiment(tweet['content'])
    else:
        tweet['sentiment'] = "neutral"

# Aggregate sentiment statistics
sentiment_counts = Counter([tweet['sentiment'] for tweet in tweets])
total_tweets = len(tweets)

sentiment_stats = {
    'positive': sentiment_counts['positive'],
    'negative': sentiment_counts['negative'],
    'neutral': sentiment_counts['neutral'],
    'total': total_tweets,
    'positive_percentage': (sentiment_counts['positive'] / total_tweets * 100) if total_tweets > 0 else 0,
    'negative_percentage': (sentiment_counts['negative'] / total_tweets * 100) if total_tweets > 0 else 0,
    'neutral_percentage': (sentiment_counts['neutral'] / total_tweets * 100) if total_tweets > 0 else 0
}

# Extract key themes
def extract_themes(tweets):
    # Keywords to look for in tweets
    theme_keywords = {
        'hybrid_reasoning': ['hybrid reasoning', 'reasoning', 'thinking', 'extended thinking'],
        'coding': ['coding', 'code', 'programming', 'developer', 'claude code'],
        'performance': ['performance', 'fast', 'speed', 'accurate', 'accuracy', 'benchmark'],
        'comparison': ['gpt', 'gpt-4', 'gpt4', 'openai', 'gemini', 'google', 'llama', 'meta'],
        'pricing': ['price', 'pricing', 'cost', 'expensive', 'cheap', 'affordable', 'worth'],
        'features': ['feature', 'capability', 'able to', 'can do', 'function'],
        'availability': ['available', 'access', 'api', 'free', 'pro', 'team', 'enterprise']
    }
    
    theme_counts = {theme: 0 for theme in theme_keywords}
    
    for tweet in tweets:
        if not tweet['content']:
            continue
            
        content_lower = tweet['content'].lower()
        for theme, keywords in theme_keywords.items():
            for keyword in keywords:
                if keyword.lower() in content_lower:
                    theme_counts[theme] += 1
                    break
    
    return theme_counts

theme_counts = extract_themes(tweets)

# Extract notable quotes
def extract_notable_quotes(tweets, top_n=10):
    # Sort tweets by engagement (likes + retweets + replies)
    if tweets and 'likes' in tweets[0] and tweets[0]['likes'] is not None:
        sorted_tweets = sorted(
            [t for t in tweets if t['content']],
            key=lambda x: (x.get('likes', 0) or 0) + (x.get('retweets', 0) or 0) + (x.get('replies', 0) or 0),
            reverse=True
        )
        return sorted_tweets[:top_n]
    else:
        # If engagement metrics aren't available, return tweets with highest positive/negative sentiment
        positive_tweets = [t for t in tweets if t['sentiment'] == 'positive' and t['content']]
        negative_tweets = [t for t in tweets if t['sentiment'] == 'negative' and t['content']]
        
        return (positive_tweets + negative_tweets)[:top_n]

notable_quotes = extract_notable_quotes(tweets)

# Save results
results = {
    'analysis_date': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    'timeframe': "February 24, 2025 - March 3, 2025",
    'total_tweets_analyzed': total_tweets,
    'sentiment_stats': sentiment_stats,
    'theme_counts': theme_counts,
    'notable_quotes': [{'content': t['content'], 'sentiment': t['sentiment']} for t in notable_quotes if t['content']]
}

# Save to JSON file
with open('/home/ubuntu/claude_analysis/twitter_analysis/sentiment_analysis_results.json', 'w') as f:
    json.dump(results, f, indent=2)

print(f"Analyzed {total_tweets} tweets")
print(f"Sentiment distribution: {sentiment_stats}")
print(f"Key themes: {theme_counts}")
print(f"Results saved to /home/ubuntu/claude_analysis/twitter_analysis/sentiment_analysis_results.json")
