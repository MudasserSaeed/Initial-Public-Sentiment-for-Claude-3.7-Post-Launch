import sys
import json
import re
import datetime
from collections import Counter

# Load the Twitter search results
with open('/home/ubuntu/claude_analysis/twitter_data/twitter_search_results_20250302_150110.json', 'r') as f:
    twitter_data = json.load(f)

# Function to extract tweets from the Twitter API response
def extract_tweets(data):
    tweets = []
    
    for query, query_results in data.items():
        for search_type, results in query_results.items():
            if isinstance(results, dict) and 'result' in results and 'timeline' in results['result']:
                timeline = results['result']['timeline']
                if 'instructions' in timeline:
                    for instruction in timeline['instructions']:
                        if 'entries' in instruction:
                            for entry in instruction['entries']:
                                # Extract user information from People module
                                if 'content' in entry and entry['content'].get('__typename') == 'TimelineTimelineModule':
                                    if 'items' in entry['content']:
                                        for item in entry['content']['items']:
                                            if 'item' in item and 'itemContent' in item['item']:
                                                item_content = item['item']['itemContent']
                                                if item_content.get('__typename') == 'TimelineUser' and 'user_results' in item_content:
                                                    user_result = item_content['user_results'].get('result', {})
                                                    if 'legacy' in user_result:
                                                        legacy = user_result['legacy']
                                                        tweet_data = {
                                                            'query': query,
                                                            'search_type': search_type,
                                                            'content': legacy.get('description', ''),
                                                            'username': legacy.get('screen_name', ''),
                                                            'name': legacy.get('name', ''),
                                                            'followers': legacy.get('followers_count', 0),
                                                            'verified': user_result.get('is_blue_verified', False),
                                                            'type': 'user_profile'
                                                        }
                                                        tweets.append(tweet_data)
                
                # Look for actual tweets in the response
                # This would require examining the actual structure of tweet entries
                # For now, we'll use the user descriptions as our content
    
    return tweets

# Simple sentiment analysis function
def analyze_sentiment(text):
    if not text:
        return "neutral"
    
    # Lists of positive and negative words/phrases
    positive_words = [
        'amazing', 'awesome', 'excellent', 'fantastic', 'great', 'impressive', 
        'love', 'best', 'better', 'improved', 'improvement', 'innovative', 
        'game-changer', 'revolutionary', 'breakthrough', 'excited', 'exciting',
        'powerful', 'fast', 'faster', 'accurate', 'accurate', 'helpful',
        'recommend', 'recommended', 'worth', 'valuable', 'useful', 'easy',
        'intuitive', 'smart', 'intelligent', 'brilliant', 'incredible',
        'outperforms', 'outperforming', 'beats', 'exceeds', 'exceeded',
        'happy', 'pleased', 'satisfied', 'satisfaction', 'impressive',
        'impressed', 'wow', 'amazing', 'cool', 'nice', 'good', 'great'
    ]
    
    negative_words = [
        'bad', 'terrible', 'awful', 'horrible', 'disappointing', 'disappointed',
        'slow', 'slower', 'buggy', 'bug', 'issue', 'problem', 'error', 'fail',
        'failed', 'failure', 'poor', 'worse', 'worst', 'useless', 'expensive',
        'overpriced', 'not worth', 'difficult', 'hard', 'complicated', 'confusing',
        'confused', 'frustrating', 'frustrated', 'frustration', 'annoying',
        'annoyed', 'hate', 'dislike', 'mediocre', 'meh', 'underwhelming',
        'underperforms', 'underperforming', 'lacks', 'lacking', 'limited',
        'limitation', 'limitations', 'not good', 'not great', 'not working',
        "doesn't work", "doesn't help", 'unhelpful', 'waste', 'wasted'
    ]
    
    # Count positive and negative words
    text_lower = text.lower()
    positive_count = sum(1 for word in positive_words if re.search(r'\b' + re.escape(word) + r'\b', text_lower))
    negative_count = sum(1 for word in negative_words if re.search(r'\b' + re.escape(word) + r'\b', text_lower))
    
    # Determine sentiment
    if positive_count > negative_count:
        return "positive"
    elif negative_count > positive_count:
        return "negative"
    else:
        return "neutral"

# Extract tweets
tweets = extract_tweets(twitter_data)

# Analyze sentiment for each tweet
for tweet in tweets:
    if tweet['content']:
        tweet['sentiment'] = analyze_sentiment(tweet['content'])
    else:
        tweet['sentiment'] = "neutral"

# Aggregate sentiment statistics
sentiment_counts = Counter([tweet['sentiment'] for tweet in tweets])
total_tweets = len(tweets)

sentiment_stats = {
    'positive': sentiment_counts['positive'],
    'negative': sentiment_counts['negative'],
    'neutral': sentiment_counts['neutral'],
    'total': total_tweets,
    'positive_percentage': (sentiment_counts['positive'] / total_tweets * 100) if total_tweets > 0 else 0,
    'negative_percentage': (sentiment_counts['negative'] / total_tweets * 100) if total_tweets > 0 else 0,
    'neutral_percentage': (sentiment_counts['neutral'] / total_tweets * 100) if total_tweets > 0 else 0
}

# Extract key themes
def extract_themes(tweets):
    # Keywords to look for in tweets
    theme_keywords = {
        'hybrid_reasoning': ['hybrid reasoning', 'reasoning', 'thinking', 'extended thinking'],
        'coding': ['coding', 'code', 'programming', 'developer', 'claude code'],
        'performance': ['performance', 'fast', 'speed', 'accurate', 'accuracy', 'benchmark'],
        'comparison': ['gpt', 'gpt-4', 'gpt4', 'openai', 'gemini', 'google', 'llama', 'meta'],
        'pricing': ['price', 'pricing', 'cost', 'expensive', 'cheap', 'affordable', 'worth'],
        'features': ['feature', 'capability', 'able to', 'can do', 'function'],
        'availability': ['available', 'access', 'api', 'free', 'pro', 'team', 'enterprise']
    }
    
    theme_counts = {theme: 0 for theme in theme_keywords}
    
    for tweet in tweets:
        if not tweet['content']:
            continue
            
        content_lower = tweet['content'].lower()
        for theme, keywords in theme_keywords.items():
            for keyword in keywords:
                if keyword.lower() in content_lower:
                    theme_counts[theme] += 1
                    break
    
    return theme_counts

theme_counts = extract_themes(tweets)

# Extract notable quotes
def extract_notable_quotes(tweets, top_n=10):
    # Sort tweets by followers count since we don't have engagement metrics
    sorted_tweets = sorted(
        [t for t in tweets if t['content']],
        key=lambda x: x.get('followers', 0) or 0,
        reverse=True
    )
    return sorted_tweets[:top_n]

notable_quotes = extract_notable_quotes(tweets)

# Save results
results = {
    'analysis_date': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    'timeframe': "February 24, 2025 - March 3, 2025",
    'total_tweets_analyzed': total_tweets,
    'sentiment_stats': sentiment_stats,
    'theme_counts': theme_counts,
    'notable_quotes': [{'content': t['content'], 'username': t['username'], 'followers': t['followers'], 'sentiment': t['sentiment']} for t in notable_quotes if t['content']]
}

# Save to JSON file
with open('/home/ubuntu/claude_analysis/twitter_analysis/sentiment_analysis_results.json', 'w') as f:
    json.dump(results, f, indent=2)

# Generate a human-readable report
report = f"""# Twitter Sentiment Analysis for Claude 3.7
## Analysis Period: February 24, 2025 - March 3, 2025
## Analysis Date: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

### Overview
- Total content analyzed: {total_tweets} items
- Sentiment distribution:
  - Positive: {sentiment_stats['positive']} ({sentiment_stats['positive_percentage']:.1f}%)
  - Negative: {sentiment_stats['negative']} ({sentiment_stats['negative_percentage']:.1f}%)
  - Neutral: {sentiment_stats['neutral']} ({sentiment_stats['neutral_percentage']:.1f}%)

### Key Themes Mentioned
"""

# Add themes to report
for theme, count in theme_counts.items():
    if count > 0:
        report += f"- {theme.replace('_', ' ').title()}: {count} mentions\n"

report += "\n### Notable Quotes\n"

# Add quotes to report
for quote in notable_quotes:
    if quote['content']:
        report += f"- @{quote['username']} ({quote['followers']} followers): \"{quote['content']}\" [Sentiment: {quote['sentiment']}]\n"

report += """
### Methodology Note
This analysis primarily examined user profiles and descriptions mentioning Claude 3.7 or related terms, as the Twitter API data structure focused on user information rather than individual tweets. A more comprehensive analysis would require additional data collection methods.
"""

# Save the report
with open('/home/ubuntu/claude_analysis/twitter_analysis/twitter_sentiment_report.md', 'w') as f:
    f.write(report)

print(f"Analyzed {total_tweets} items")
print(f"Sentiment distribution: {sentiment_stats}")
print(f"Key themes: {theme_counts}")
print(f"Results saved to /home/ubuntu/claude_analysis/twitter_analysis/sentiment_analysis_results.json")
print(f"Report saved to /home/ubuntu/claude_analysis/twitter_analysis/twitter_sentiment_report.md")
