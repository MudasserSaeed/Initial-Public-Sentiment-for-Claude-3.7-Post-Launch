import sys
sys.path.append('/opt/.manus/.sandbox-runtime')
from data_api import ApiClient
import json
import datetime

client = ApiClient()

# Define search queries
search_queries = [
    "Claude 3.7",
    "Claude 3.7 Sonnet",
    "Claude 3.7 hybrid reasoning",
    "Claude Code",
    "Anthropic Claude 3.7"
]

# Define search types
search_types = ["Top", "Latest"]

# Store results
all_results = {}

# Search for each query and type
for query in search_queries:
    all_results[query] = {}
    for search_type in search_types:
        print(f"Searching for '{query}' with type '{search_type}'...")
        
        # Call Twitter search API with count as string
        results = client.call_api('Twitter/search_twitter', query={
            'query': query,
            'count': "20",  # Using string instead of integer
            'type': search_type
        })
        
        # Save results
        all_results[query][search_type] = results
        
        # Print some basic info
        if results and 'result' in results and 'timeline' in results['result'] and 'instructions' in results['result']['timeline']:
            for instruction in results['result']['timeline']['instructions']:
                if 'entries' in instruction:
                    print(f"Found {len(instruction['entries'])} entries")
        else:
            print("No entries found or unexpected response structure")

# Save all results to a JSON file
timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
output_file = f"/home/ubuntu/claude_analysis/twitter_data/twitter_search_results_{timestamp}.json"

with open(output_file, 'w') as f:
    json.dump(all_results, f, indent=2)

print(f"Results saved to {output_file}")
