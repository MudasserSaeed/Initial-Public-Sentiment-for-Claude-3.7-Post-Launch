import json
import datetime

# Store YouTube video data
youtube_videos = [
    {
        "title": "New Claude 3.7 Sonnet Just CRUSHED Every AI Model",
        "url": "https://www.youtube.com/watch?v=0CrCpXAC2vA",
        "upload_date": "February 26, 2025",
        "days_since_launch": 2
    },
    {
        "title": "Claude 3.7 Sonnet–Code",
        "url": "https://www.youtube.com/watch?v=DxCTPvkxGbA",
        "upload_date": "February 25, 2025",
        "days_since_launch": 1
    },
    {
        "title": "The Evolution of Hybrid Reasoning in Artificial Intelligence",
        "url": "https://www.youtube.com/watch?v=zQ7DXIMoTiA",
        "upload_date": "February 26, 2025",
        "days_since_launch": 2
    },
    {
        "title": "World's first hybrid AI model. How it works and when to use it",
        "url": "https://www.youtube.com/watch?v=9WKO-36Nnu0",
        "upload_date": "February 26, 2025",
        "days_since_launch": 2
    },
    {
        "title": "Claude 3.7 goes hard for programmers…",
        "url": "https://www.youtube.com/watch?v=x2WtHZciC74",
        "upload_date": "February 26, 2025",
        "days_since_launch": 2
    },
    {
        "title": "Claude 3.7 is pure insanity",
        "url": "https://www.youtube.com/watch?v=afN8U7kAiLc",
        "upload_date": "February 27, 2025",
        "days_since_launch": 3
    },
    {
        "title": "You Have to See This! (Claude 3.7 Sonnet)",
        "url": "https://www.youtube.com/watch?v=ohp4sxB4JLQ",
        "upload_date": "February 25, 2025",
        "days_since_launch": 1
    },
    {
        "title": "Claude 3.7 is More Significant than its Name Implies (ft DeepSeek)",
        "url": "https://www.youtube.com/watch?v=IziXJt5iUHo",
        "upload_date": "February 25, 2025",
        "days_since_launch": 1
    },
    {
        "title": "Anthropic Claude Sonnet 3.7 in 8 Minutes",
        "url": "https://www.youtube.com/watch?v=LmBvVZbLN34",
        "upload_date": "February 25, 2025",
        "days_since_launch": 1
    }
]

# Save the YouTube video data to a JSON file
with open('/home/ubuntu/claude_analysis/youtube_data/youtube_videos.json', 'w') as f:
    json.dump(youtube_videos, f, indent=2)

print(f"Saved data for {len(youtube_videos)} YouTube videos about Claude 3.7")
print(f"Data saved to /home/ubuntu/claude_analysis/youtube_data/youtube_videos.json")
