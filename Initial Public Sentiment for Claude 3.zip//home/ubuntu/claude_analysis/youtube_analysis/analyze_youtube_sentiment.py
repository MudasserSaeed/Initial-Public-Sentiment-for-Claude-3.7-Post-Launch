import json
import re
import datetime
from collections import Counter

# Load the YouTube video data
with open('/home/ubuntu/claude_analysis/youtube_data/youtube_videos.json', 'r') as f:
    youtube_videos = json.load(f)

# Initial sentiment analysis based on video titles
def analyze_title_sentiment(title):
    # Lists of positive and negative words/phrases
    positive_words = [
        'amazing', 'awesome', 'excellent', 'fantastic', 'great', 'impressive', 
        'love', 'best', 'better', 'improved', 'improvement', 'innovative', 
        'game-changer', 'revolutionary', 'breakthrough', 'excited', 'exciting',
        'powerful', 'fast', 'faster', 'accurate', 'accurate', 'helpful',
        'recommend', 'recommended', 'worth', 'valuable', 'useful', 'easy',
        'intuitive', 'smart', 'intelligent', 'brilliant', 'incredible',
        'outperforms', 'outperforming', 'beats', 'exceeds', 'exceeded',
        'happy', 'pleased', 'satisfied', 'satisfaction', 'impressive',
        'impressed', 'wow', 'amazing', 'cool', 'nice', 'good', 'great',
        'crushed', 'pure insanity', 'significant', 'hard for programmers'
    ]
    
    negative_words = [
        'bad', 'terrible', 'awful', 'horrible', 'disappointing', 'disappointed',
        'slow', 'slower', 'buggy', 'bug', 'issue', 'problem', 'error', 'fail',
        'failed', 'failure', 'poor', 'worse', 'worst', 'useless', 'expensive',
        'overpriced', 'not worth', 'difficult', 'hard', 'complicated', 'confusing',
        'confused', 'frustrating', 'frustrated', 'frustration', 'annoying',
        'annoyed', 'hate', 'dislike', 'mediocre', 'meh', 'underwhelming',
        'underperforms', 'underperforming', 'lacks', 'lacking', 'limited',
        'limitation', 'limitations', 'not good', 'not great', 'not working',
        "doesn't work", "doesn't help", 'unhelpful', 'waste', 'wasted'
    ]
    
    # Count positive and negative words
    title_lower = title.lower()
    positive_count = sum(1 for word in positive_words if re.search(r'\b' + re.escape(word) + r'\b', title_lower))
    negative_count = sum(1 for word in negative_words if re.search(r'\b' + re.escape(word) + r'\b', title_lower))
    
    # Determine sentiment
    if positive_count > negative_count:
        return "positive"
    elif negative_count > positive_count:
        return "negative"
    else:
        # For titles, we'll consider certain phrases as indicators of positive sentiment
        if any(phrase in title_lower for phrase in ['crushed', 'pure insanity', 'have to see this', 'more significant']):
            return "positive"
        return "neutral"

# Extract key themes from video titles
def extract_themes_from_title(title):
    title_lower = title.lower()
    themes = []
    
    theme_keywords = {
        'hybrid_reasoning': ['hybrid reasoning', 'hybrid', 'reasoning', 'thinking'],
        'coding': ['coding', 'code', 'programming', 'programmers', 'developers'],
        'performance': ['performance', 'fast', 'speed', 'crushed', 'outperforms'],
        'comparison': ['every ai model', 'other models', 'gpt', 'openai', 'gemini', 'google'],
        'features': ['feature', 'capability', 'sonnet'],
        'innovation': ['first', 'revolutionary', 'breakthrough', 'insanity', 'significant']
    }
    
    for theme, keywords in theme_keywords.items():
        for keyword in keywords:
            if keyword in title_lower:
                themes.append(theme)
                break
    
    return themes

# Analyze each video
for video in youtube_videos:
    video['title_sentiment'] = analyze_title_sentiment(video['title'])
    video['themes'] = extract_themes_from_title(video['title'])

# Aggregate sentiment statistics
sentiment_counts = Counter([video['title_sentiment'] for video in youtube_videos])
total_videos = len(youtube_videos)

sentiment_stats = {
    'positive': sentiment_counts['positive'],
    'negative': sentiment_counts['negative'],
    'neutral': sentiment_counts['neutral'],
    'total': total_videos,
    'positive_percentage': (sentiment_counts['positive'] / total_videos * 100) if total_videos > 0 else 0,
    'negative_percentage': (sentiment_counts['negative'] / total_videos * 100) if total_videos > 0 else 0,
    'neutral_percentage': (sentiment_counts['neutral'] / total_videos * 100) if total_videos > 0 else 0
}

# Aggregate theme statistics
all_themes = []
for video in youtube_videos:
    all_themes.extend(video['themes'])

theme_counts = Counter(all_themes)

# Manual content analysis based on the first video viewed
content_analysis = {
    "https://www.youtube.com/watch?v=0CrCpXAC2vA": {
        "title": "New Claude 3.7 Sonnet Just CRUSHED Every AI Model In The World! (First HYBRID REASONING Model Ever)",
        "sentiment": "positive",
        "key_points": [
            "Claude 3.7 Sonnet is described as Anthropic's most advanced AI model",
            "Features hybrid reasoning that combines fast responses with deep analytical thinking",
            "Excels at coding, problem-solving, and AI-assisted development",
            "Has extended thinking mode, Claude Code for automation, and 128,000-token context window",
            "Outperforms competitors in real-world coding tasks, software debugging, and autonomous interactions"
        ],
        "notable_quotes": [
            "Claude 3.7 Sonnet is Anthropic's most advanced AI model, featuring hybrid reasoning that combines fast responses with deep analytical thinking.",
            "This AI model outperforms competitors in real-world coding tasks, software debugging, and autonomous computer interactions.",
            "Claude 3.7 Sonnet's cutting-edge AI capabilities, showing how it advances AI-assisted coding, problem-solving, and deep analytical thinking, setting a new benchmark in artificial intelligence."
        ]
    }
}

# Save results
results = {
    'analysis_date': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    'timeframe': "February 24, 2025 - March 3, 2025",
    'total_videos_analyzed': total_videos,
    'sentiment_stats': sentiment_stats,
    'theme_counts': dict(theme_counts),
    'video_analysis': youtube_videos,
    'content_analysis': content_analysis
}

# Save to JSON file
with open('/home/ubuntu/claude_analysis/youtube_analysis/youtube_sentiment_results.json', 'w') as f:
    json.dump(results, f, indent=2)

# Generate a human-readable report
report = f"""# YouTube Sentiment Analysis for Claude 3.7
## Analysis Period: February 24, 2025 - March 3, 2025
## Analysis Date: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

### Overview
- Total videos analyzed: {total_videos} videos
- Sentiment distribution (based on video titles):
  - Positive: {sentiment_stats['positive']} ({sentiment_stats['positive_percentage']:.1f}%)
  - Negative: {sentiment_stats['negative']} ({sentiment_stats['negative_percentage']:.1f}%)
  - Neutral: {sentiment_stats['neutral']} ({sentiment_stats['neutral_percentage']:.1f}%)

### Key Themes Mentioned
"""

# Add themes to report
for theme, count in theme_counts.items():
    report += f"- {theme.replace('_', ' ').title()}: {count} mentions\n"

report += """
### Video Title Analysis
"""

# Add video analysis to report
for video in youtube_videos:
    report += f"- **{video['title']}** [Days since launch: {video['days_since_launch']}]\n"
    report += f"  - Sentiment: {video['title_sentiment']}\n"
    report += f"  - Themes: {', '.join([theme.replace('_', ' ').title() for theme in video['themes']])}\n"
    report += f"  - URL: {video['url']}\n\n"

report += """
### Content Analysis
"""

# Add content analysis to report
for url, analysis in content_analysis.items():
    report += f"#### {analysis['title']}\n"
    report += f"- **Sentiment**: {analysis['sentiment']}\n"
    report += f"- **Key Points**:\n"
    for point in analysis['key_points']:
        report += f"  - {point}\n"
    report += f"- **Notable Quotes**:\n"
    for quote in analysis['notable_quotes']:
        report += f"  - \"{quote}\"\n"
    report += f"- **URL**: {url}\n\n"

report += """
### Methodology Note
This analysis examined YouTube video titles and content related to Claude 3.7 during its first week post-launch. Sentiment analysis was performed on video titles, and key themes were extracted. For the first video, a detailed content analysis was performed to identify key points and notable quotes.
"""

# Save the report
with open('/home/ubuntu/claude_analysis/youtube_analysis/youtube_sentiment_report.md', 'w') as f:
    f.write(report)

print(f"Analyzed {total_videos} YouTube videos")
print(f"Sentiment distribution: {sentiment_stats}")
print(f"Key themes: {dict(theme_counts)}")
print(f"Results saved to /home/ubuntu/claude_analysis/youtube_analysis/youtube_sentiment_results.json")
print(f"Report saved to /home/ubuntu/claude_analysis/youtube_analysis/youtube_sentiment_report.md")
